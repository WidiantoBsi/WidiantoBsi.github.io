<div class="modal animated pulse" id="PopupJabatan" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <form action="<?php echo base_url('PageHome').'/AddKaryawan'; ?>" method="post">
      <div class="modal-content">
        <div class="modal-header">
          <h3 class="modal-title" id="myModalLabel">Tambah Data Karyawan</h3>
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        </div>
        <div class="modal-body">
          
        </div>
        <div class="modal-footer">
          <input type="submit" value="Simpan Data"  class="btn btn-sm btn-primary"/>
        </div>
      </div>
    </form>
  </div>
</div>