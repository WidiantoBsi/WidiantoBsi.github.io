<?php
class QR {

    function __construct() {
        include_once APPPATH . '/phpqrcode/qrlib.php';
    }
}
?>