<?php
class Excel {

    function __construct() {
        include_once APPPATH . '/third_party/PHPExcel/PHPExcel.php';
    }
}
?>